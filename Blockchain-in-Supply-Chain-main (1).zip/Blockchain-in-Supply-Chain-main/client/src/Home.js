import React from 'react'
import { useHistory } from "react-router-dom"
import './Home.css'

function Home() {
    const history = useHistory()
    const redirect_to_roles = () => {
        history.push('/indviregister')
    }
    const redirect_to_addmed = () => {
        history.push('/addmed')
    }
    const redirect_to_supply = () => {
        history.push('/supply')
    }
    const redirect_to_track = () => {
        history.push('/track')
    }
    return (
        <div className='homefullbody'>
        <div className="homeheading">
        <h3 id='foodsupply'>Food Supply Chain Flow  </h3>
        </div>
        
            <div className="homebody">
                {/* <div className="homeleft">
                
                </div> */}
                <h1 id='titlehead'><span id='spanletter'>O</span>rder,<span id='spanletter'>C</span>ontrol,<span id='spanletter'>T</span>rack your Product</h1>
                {/* <div className='homeright'> */}
                
                    {/* <h6>(Note: Here <u>Owner</u> is the person who deployed the smart contract on the blockchain)</h6>
                    <h5>Step 1: Owner Should Register Raw material suppliers ,Manufacturers, Distributors and Retailers</h5>
                    <h6>(Note: This is a one time step. Skip to step 2 if already done)</h6> */}
                    <button onClick={redirect_to_roles} className="register" id='homerightbtn'>Register</button>
                    <br />
                    {/* <h5>Step 2: Owner should order Products</h5> */}
                    <button onClick={redirect_to_addmed}  className="order" id='homerightbtn'>Order Products</button>
                    <br />
                    {/* <h5>Step 3: Control Supply Chain</h5> */}
                    <button onClick={redirect_to_supply}  className="control" id='homerightbtn'>Control Supply Chain</button>
                   <br />
                    {/* <hr /> */}
                    
                    {/* <h5><b>Track</b> the Products:</h5> */}
                    <button onClick={redirect_to_track}  className="track" id='homerightbtn'>Track Products</button>
                {/* </div> */}
            </div>
            </div>
    )
}

export default Home
