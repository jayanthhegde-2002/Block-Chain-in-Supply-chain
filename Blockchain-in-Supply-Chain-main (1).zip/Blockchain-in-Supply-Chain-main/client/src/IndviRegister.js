import React from 'react';
import { Link } from 'react-router-dom';
import './IndviRegister.css';
import { useHistory } from "react-router-dom"
const HomePage = () => {
  const history = useHistory()
  const handleHover = (e) => {
    e.target.style.transform = 'translateY(-20px)'; // Move up 5px
    // e.target.style.backgroundColor = 'lightblue'; // Change color on hover
  };
  const redirect_to_home = () => {
    history.push('/')
}
  const handleLeave = (e) => {
    e.target.style.transform = 'translateY(0)'; // Reset position
    e.target.style.backgroundColor = 'white'; // Reset color
  };

  return (
    <div id='indviregister'>
  <span onClick={redirect_to_home} className="btn btn-outline-danger btn-sm"id='homebtn'> HOME</span><br></br> <br></br>

      <h1 id='welcomeheading'>Welcome to Registration Page </h1>
      <div className="button-container">
        <Link to="/rawmaterial">
          <button className="hover-button" onMouseEnter={handleHover} onMouseLeave={handleLeave}  id='rawmaterialbtn'>
            RAW MATERIAL 
          </button>
        </Link>
        <Link to="/manufacturer">
          <button className="hover-button" onMouseEnter={handleHover} onMouseLeave={handleLeave} id='manufacturerbtn'>
            <span id='manuheading'>MANUFACTURER</span>
          </button>
        </Link>
        <Link to="/distributor">
          <button className="hover-button" onMouseEnter={handleHover} onMouseLeave={handleLeave} id='distributorbtn'>
            <span id='dishead'>DISTRIBUTOR</span>
          </button>
        </Link>
        <Link to="/regulator">
          <button className="hover-button" onMouseEnter={handleHover} onMouseLeave={handleLeave} id='regulatorbtn'>
            REGULATOR
          </button>
        </Link>
        <Link to="/retailer">
          <button className="hover-button" onMouseEnter={handleHover} onMouseLeave={handleLeave} id='retailerbtn'>
            RETAILER
          </button>
        </Link>
      </div>
    </div>
  );
};

export default HomePage;
