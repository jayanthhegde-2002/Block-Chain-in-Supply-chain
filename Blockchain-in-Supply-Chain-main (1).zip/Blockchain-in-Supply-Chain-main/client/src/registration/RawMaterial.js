import React, { useState, useEffect } from 'react';
import Web3 from "web3";
import SupplyChainABI from "../artifacts/SupplyChain.json"
import { useHistory } from "react-router-dom"
import './RawMaterial.css'
const RawMaterail = ()=> {
    const history = useHistory()
    useEffect(() => {
        loadWeb3();
        loadBlockchaindata();
    }, [])
    const [currentaccount, setCurrentaccount] = useState("");
    const [accountName, setAccountName] = useState("");
    const [loader, setloader] = useState(true);
    const [SupplyChain, setSupplyChain] = useState();
    const [RMSname, setRMSname] = useState();
    const [RMSplace, setRMSplace] = useState();
    const [RMSaddress, setRMSaddress] = useState();
    const [RMS, setRMS] = useState();


    const loadWeb3 = async () => {
        if (window.ethereum) {
            window.web3 = new Web3(window.ethereum);
            await window.ethereum.enable();
        } else if (window.web3) {
            window.web3 = new Web3(window.web3.currentProvider);
        } else {
            window.alert(
                "Non-Ethereum browser detected. You should consider trying MetaMask!"
            );
        }
    };

    const loadBlockchaindata = async () => {
        setloader(true);
        const web3 = window.web3;
        const accounts = await web3.eth.getAccounts();
        const account = accounts[0];
        setCurrentaccount(account);
        const accountNameMapping = {
            '0x87556f11072d6A208671Df747FE70B53CBB3aeA3': 'Owner',
            '0xCd462c2403E3281bC6d56747d0950cA3871aaCaA': 'Raw Material',
            '0xCB20F962907C9452A23e90d805fC83e2350F0217': 'Manufacturer',
            '0x5445b85D1e3cFe14951df1E2620F70c2f2271Af7': 'Distributer',
            '0x37CDF8114a832E00b3265aD3167bAe5614f6dDdA': 'Regulator',
            '0x85470cbfC841B1DF0E217A95D19c34dfbc5F9134': 'Retailer'
            // Add more mappings as needed
        };

         // Get the account name from the mapping or set it to 'Unknown' if not found
         const accountName = accountNameMapping[account] || 'Unknown';
         setAccountName(accountName);
         const networkId = await web3.eth.net.getId();
         const networkData = SupplyChainABI.networks[networkId];
         if (networkData) {
             const supplychain = new web3.eth.Contract(SupplyChainABI.abi, networkData.address);
             setSupplyChain(supplychain);
             var i;
             const rmsCtr = await supplychain.methods.rmsCtr().call();
             const rms = {};
             for (i = 0; i < rmsCtr; i++) {
                 rms[i] = await supplychain.methods.RMS(i + 1).call();
             }
             setRMS(rms);
             setloader(false);
        }
        else {
            window.alert('The smart contract is not deployed to current network')
        }
    }
    if (loader) {
        return (
            <div>
                <h1 className="wait">Loading...</h1>
            </div>
        )

    }
    const redirect_to_home = () => {
        history.push('/')
    }
    const redirect_to_registration=()=>{
        history.push('/indviregister')
    }
    const handlerChangeAddressRMS = (event) => {
        setRMSaddress(event.target.value);
    }
    const handlerChangePlaceRMS = (event) => {
        setRMSplace(event.target.value);
    }
    const handlerChangeNameRMS = (event) => {
        setRMSname(event.target.value);
    }
    const handlerSubmitRMS = async (event) => {
        event.preventDefault();
        try {
            var reciept = await SupplyChain.methods.addRMS(RMSaddress, RMSname, RMSplace).send({ from: currentaccount });
            if (reciept) {
                loadBlockchaindata();
            }
        }
        catch (err) {
            alert("Unauthorized Access!!!")
        }
    }

    return(
        <div id='rawmaterial'>
           

           
            <span onClick={redirect_to_home} className="btn btn-outline-danger btn-sm" id='homebtn'>HOME</span>
            <span id='acctitle'><b>Current Account Address:</b> {accountName}</span>
            <span onClick={redirect_to_registration} className="btn btn-outline-danger btn-sm" id='regbtn'>Registration Page</span>
            
            <h4 id='rawtitle'>Raw Material Suppliers</h4>
            <form onSubmit={handlerSubmitRMS} id='handlersubmitrms'>
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeAddressRMS} placeholder="Ethereum Address" required />
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeNameRMS} placeholder="Raw Material Supplier Name" required />
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangePlaceRMS} placeholder="Based In" required />
                <button className="btn btn-success btn-sm" id='handlerSubmitRMSbtn' onSubmit={handlerSubmitRMS}>Register</button>
            </form>
            <table className="table table-borderless" id='table1'>
                <thead>
                    <tr>
                        <th scope="col" id='tblelements'>ID</th>
                        <th scope="col" id='tblelements'>Name</th>
                        <th scope="col" id='tblelements'>Place</th>
                        <th scope="col" id='tblelements'>Ethereum Address</th>
                    </tr>
                </thead>
                <tbody>
                    {Object.keys(RMS).map(function (key) {
                        return (
                            <tr key={key}>
                                <td id='tblelements'>{RMS[key].id}</td>
                                <td id='tblelements'>{RMS[key].name}</td>
                                <td id='tblelements'>{RMS[key].place}</td>
                                <td id='tblelements'>{RMS[key].addr}</td>
                            </tr>
                        )
                    })}
                </tbody>
            </table>
            </div>
    )



}
export default RawMaterail