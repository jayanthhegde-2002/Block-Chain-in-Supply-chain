import React, { useState, useEffect } from 'react'
import { useHistory } from "react-router-dom"
import Web3 from "web3";
import SupplyChainABI from "./artifacts/SupplyChain.json"
import './Supply.css'

function Supply() {
    const history = useHistory()
    useEffect(() => {
        loadWeb3();
        loadBlockchaindata();
    }, [])

    const [currentaccount, setCurrentaccount] = useState("");
    const [accountName, setAccountName] = useState("");
    const [loader, setloader] = useState(true);
    const [SupplyChain, setSupplyChain] = useState();
    const [MED, setMED] = useState();
    const [MedStage, setMedStage] = useState();
    const [MedDes, setMedDes] = useState();
    const [ID, setID] = useState();


    const loadWeb3 = async () => {
        if (window.ethereum) {
            window.web3 = new Web3(window.ethereum);
            await window.ethereum.enable();
        } else if (window.web3) {
            window.web3 = new Web3(window.web3.currentProvider);
        } else {
            window.alert(
                "Non-Ethereum browser detected. You should consider trying MetaMask!"
            );
        }
    };
    const loadBlockchaindata = async () => {
        setloader(true);
        const web3 = window.web3;
        const accounts = await web3.eth.getAccounts();
        const account = accounts[0];
        setCurrentaccount(account);
        const accountNameMapping = {
            '0x87556f11072d6A208671Df747FE70B53CBB3aeA3': 'Owner',
            '0xCd462c2403E3281bC6d56747d0950cA3871aaCaA': 'Raw Material',
            '0xCB20F962907C9452A23e90d805fC83e2350F0217': 'Manufacturer',
            '0x5445b85D1e3cFe14951df1E2620F70c2f2271Af7': 'Distributer',
            '0x37CDF8114a832E00b3265aD3167bAe5614f6dDdA': 'Regulator',
            '0x85470cbfC841B1DF0E217A95D19c34dfbc5F9134': 'Retailer'
            // Add more mappings as needed
        };
    
        // Get the account name from the mapping or set it to 'Unknown' if not found
        const accountName = accountNameMapping[account] || 'Unknown';
        setAccountName(accountName);
        const networkId = await web3.eth.net.getId();
        const networkData = SupplyChainABI.networks[networkId];
        if (networkData) {
            const supplychain = new web3.eth.Contract(SupplyChainABI.abi, networkData.address);
            setSupplyChain(supplychain);
            var i;
            const medCtr = await supplychain.methods.medicineCtr().call();
            const med = {};
            const medStage = [];
            for (i = 0; i < medCtr; i++) {
                med[i] = await supplychain.methods.MedicineStock(i + 1).call();
                medStage[i] = await supplychain.methods.showStage(i + 1).call();
            }
            setMED(med);
            setMedStage(medStage);
            setloader(false);
        }
        else {
            window.alert('The smart contract is not deployed to current network')
        }
    }
    if (loader) {
        return (
            <div>
                <h1 className="wait">Loading...</h1>
            </div>
        )

    }
    const redirect_to_home = () => {
        history.push('/')
    }
    const handlerChangeID = (event) => {
        setID(event.target.value);
    }
    const handlerChangeDesMED = (event) => {
        setMedDes(event.target.value);
    }
    const handlerSubmitRMSsupply = async (event) => {
        event.preventDefault();
        try {
            var reciept = await SupplyChain.methods.RMSsupply(ID,MedDes).send({ from: currentaccount });
            if (reciept) {
                loadBlockchaindata();
            }
        }
        catch (err) {
            alert("Unauthorized Access!!!")
        }
    }
    const handlerSubmitManufacturing = async (event) => {
        event.preventDefault();
        try {
            var reciept = await SupplyChain.methods.Manufacturing(ID,MedDes).send({ from: currentaccount });
            if (reciept) {
                loadBlockchaindata();
            }
        }
        catch (err) {
            alert("Unauthorized Access!!!")
        }
    }
    const handlerSubmitDistribute = async (event) => {
        event.preventDefault();
        try {
            var reciept = await SupplyChain.methods.Distribute(ID,MedDes).send({ from: currentaccount });
            if (reciept) {
                loadBlockchaindata();
            }
        }
        catch (err) {
            alert("Unauthorized Access!!!")
        }
    }
    const handlerSubmitRegulator = async (event) => {
        event.preventDefault();
        try {
            var reciept = await SupplyChain.methods.Regulator(ID,MedDes).send({ from: currentaccount });
            if (reciept) {
                loadBlockchaindata();
            }
        }
        catch (err) {
            alert("Unauthorized Access!!!")
        }
    }
    const handlerSubmitRetail = async (event) => {
        event.preventDefault();
        try {
            var reciept = await SupplyChain.methods.Retail(ID,MedDes).send({ from: currentaccount });
            if (reciept) {
                loadBlockchaindata();
            }
        }
        catch (err) {
            alert("Unauthorized Access!!!")
        }
    }
    const handlerSubmitSold = async (event) => {
        event.preventDefault();
        try {
            var reciept = await SupplyChain.methods.sold(ID,MedDes).send({ from: currentaccount });
            if (reciept) {
                loadBlockchaindata();
            }
        }
        catch (err) {
            alert("Unauthorized Access!!!")
        }
    }
    return (
        <div id='supplypage'>
            <span id='supplyacctitle' ><b>Current Account Address:</b> {accountName}</span>
            <span onClick={redirect_to_home} id='homebtn' className="btn btn-outline-danger btn-sm"> HOME</span>
            <h6><b>Supply Chain Flow:</b></h6>
            <p>Product Order -&gt; Raw Material Supplier -&gt; Manufacturer -&gt; Distributor -&gt; Retailer -&gt; Consumer</p>
            <table className="table table-sm table-dark">
                <thead>
                    <tr>
                        <th scope="col">Product ID</th>
                        <th scope="col">Name</th>
                        <th scope="col">Description</th>
                        <th scope="col">Current Processing Stage</th>
                    </tr>
                </thead>
                <tbody>
                    {Object.keys(MED).map(function (key) {
                        return (
                            <tr key={key}>
                                <td>{MED[key].id}</td>
                                <td>{MED[key].name}</td>
                                <td>{MED[key].description}</td>
                                <td>
                                    {
                                        MedStage[key]
                                    }
                                </td>
                            </tr>
                        )
                    })}
                </tbody>
            </table>
            <h5 id='stepheading'><b>Step 1: Supply Raw Materials</b>(Only a registered Raw Material Supplier can perform this step):-</h5>
            <form onSubmit={handlerSubmitRMSsupply} id='supplyform'>
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeID} placeholder="Enter Product ID" required />
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeDesMED} placeholder="Product Description" required />
                <button className="btn btn-success btn-sm" id='formbtn' onSubmit={handlerSubmitRMSsupply}>Supply</button>
            </form>
            <hr />
            <br />
            <h5 id='stepheading'><b>Step 2: Manufacture</b>(Only a registered Manufacturer can perform this step):-</h5>
            <form onSubmit={handlerSubmitManufacturing} id='supplyform'>
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeID} placeholder="Enter Product ID" required />
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeDesMED} placeholder="Product Description" required />
                <button className="btn btn-success btn-sm" id='formbtn' onSubmit={handlerSubmitManufacturing}>Manufacture</button>
            </form>
            <hr />
            <br />
            <h5 id='stepheading'><b>Step 3: Distribute</b>(Only a registered Distributor can perform this step):-</h5>
            <form onSubmit={handlerSubmitDistribute} id='supplyform'>
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeID} placeholder="Enter Product ID" required />
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeDesMED} placeholder="Product Description" required />
                <button className="btn btn-success btn-sm" id='formbtn' onSubmit={handlerSubmitDistribute}>Distribute</button>
            </form>
            <hr />
            <br />
            <h5 id='stepheading'><b>Step 4: Retail</b>(Only a registered Retailer can perform this step):-</h5>
            <form onSubmit={handlerSubmitRetail} id='supplyform'>
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeID} placeholder="Enter Product ID" required />
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeDesMED} placeholder="Product Description" required />
                <button className="btn btn-success btn-sm" id='formbtn' onSubmit={handlerSubmitRetail}>Retail</button>
            </form>
            <hr />
            <br />
            <h5 id='stepheading'><b>Step 5: Regulator</b>(Only a registered Regulator can perform this step):-</h5>
            <form onSubmit={handlerSubmitRegulator} id='supplyform'>
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeID} placeholder="Enter Product ID" required />
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeDesMED} placeholder="Product Description" required />
                <button className="btn btn-success btn-sm" id='formbtn' onSubmit={handlerSubmitRegulator}>Regulator</button>
            </form>
            <hr />
            <br />
            <h5 id='stepheading'><b>Step 6: Mark as sold</b>(Only a registered Retailer can perform this step):-</h5>
            <form onSubmit={handlerSubmitSold} id='supplyform'>
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeID} placeholder="Enter Product ID" required />
                <input className="form-control-sm" id='input1' type="text" onChange={handlerChangeDesMED} placeholder="Product Description" required />
                <button className="btn btn-success btn-sm" id='formbtn' onSubmit={handlerSubmitSold}>Sold</button>
            </form>
            <hr />
        </div>
    )
}

export default Supply
